import React, { useEffect } from "react";
import { motion } from "framer-motion";
import {
  Phone,
  Wrench,
  Wind,
  Cable,
  Truck,
  Factory,
  Search,
  MapPin,
  ShieldCheck,
  Clock,
  Bolt,
  Settings,
  Mail,
  MessageCircle,
} from "lucide-react";

const CONTACT = {
  phoneDisp: "082 457 5394",
  phoneHref: "+27824575394",
  email: "werneruf@gmail.com",
  whatsappHref: "https://wa.me/27824575394",
  address: "26 Langa Crescent, Zeekoewater 311-Js, eMalahleni, 1035",
  hours: {
    monThu: "08:00 – 16:00",
    fri: "08:00 – 13:00",
    callouts: "24/7",
  },
};

const SERVICES = [
  { icon: Cable, title: "Harness Manufacturing", blurb: "Designed, built and tested in-house for harsh mine conditions." },
  { icon: Wrench, title: "Auto Electrical Parts", blurb: "OEM-grade components supplied and fitted with warranty." },
  { icon: Factory, title: "Cab Refurb & Rebuilds", blurb: "From strip-down to final QC—clean, safe, mine-ready." },
  { icon: Wind, title: "Air‑con Repairs & Parts", blurb: "Leak detection, compressors, condensers—full A/C service." },
  { icon: Search, title: "Fault Finding", blurb: "Advanced diagnostics to trace faults fast and prevent repeat issues." },
  { icon: Truck, title: "Mobile Field Service", blurb: "On-site repairs across Mpumalanga and SA—we come to you." },
];

const BRANDS = [
  { src: "/brands/komatsu.svg", name: "Komatsu" },
  { src: "/brands/caterpillar.svg", name: "Caterpillar" },
  { src: "/brands/hitachi.svg", name: "Hitachi" },
  { src: "/brands/volvo.svg", name: "Volvo" },
  { src: "/brands/bell.svg", name: "Bell" },
];

export default function Home(): JSX.Element {
  useEffect(() => {
    try {
      console.assert(Array.isArray(SERVICES) && SERVICES.length >= 3, "SERVICES should have items");
    } catch {}
  }, []);

  return (
    <div className="min-h-screen bg-black text-zinc-100 selection:bg-orange-500/30 selection:text-white">
      <SiteHeader />
      <Hero />
      <TrustStrip />
      <ServicesSection />
      <Industries />
      <About />
      <Gallery />
      <BrandsStrip />
      <CTA />
      <SiteFooter />
    </div>
  );
}

function SiteHeader(): JSX.Element {
  return (
    <header className="fixed inset-x-0 top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-black/40 bg-black/70 border-b border-white/5">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/upfront-auto-electrical-logo.svg" alt="Upfront Auto Electrical logo" className="h-8 w-auto" />
            <span className="sr-only">Upfront Auto Electrical</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm text-zinc-300">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#industries" className="hover:text-white">Industries</a>
            <a href="#work" className="hover:text-white">Work</a>
            <a href="#about" className="hover:text-white">About</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href={CONTACT.whatsappHref} className="inline-flex items-center gap-2 rounded-2xl border border-green-500/30 bg-green-500/10 px-3 py-2 text-sm font-semibold text-green-400 hover:bg-green-500/20 transition">
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
            <a href={`tel:${CONTACT.phoneHref}`} className="inline-flex items-center gap-2 rounded-2xl border border-orange-500/30 bg-orange-500/10 px-4 py-2 text-sm font-semibold text-orange-400 hover:bg-orange-500/20 transition">
              <Phone className="h-4 w-4" /> {CONTACT.phoneDisp}
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}

function Hero(): JSX.Element {
  return (
    <section className="relative isolate pt-24">
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <video className="h-full w-full object-cover opacity-60" autoPlay muted loop playsInline poster="/hero-fallback.jpg">
          <source src="/video/hero.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/60 to-black" />
        <div
          className="absolute inset-0 mix-blend-overlay opacity-20"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, rgba(255,255,255,0.06), transparent 30%), radial-gradient(circle at 80% 0%, rgba(255,255,255,0.05), transparent 25%), radial-gradient(circle at 60% 80%, rgba(255,255,255,0.04), transparent 25%)",
          }}
        />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-24">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="max-w-3xl">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs tracking-widest uppercase text-zinc-300">
            <Bolt className="h-3 w-3 text-orange-400" /> Celebrating 20 Years
          </p>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight">
            WHEN PERFORMANCE MATTERS, <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">GO UPFRONT.</span>
          </h1>
          <p className="mt-5 text-zinc-300 text-base sm:text-lg max-w-2xl">
            When performance matters, go Upfront. For over 20 years, Upfront Auto Electrical has been the go‑to name in heavy‑duty auto electrical repairs, harness manufacturing, cab refurbishments, and mobile field service across eMalahleni, Witbank, and Mpumalanga.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a href="#contact" className="rounded-2xl bg-orange-500 px-5 py-3 font-semibold text-black hover:bg-orange-400 transition shadow-[0_0_0_2px_rgba(255,122,0,0.3)]">Book a Site Visit</a>
            <a href="#services" className="rounded-2xl border border-white/10 px-5 py-3 font-semibold text-white/90 hover:bg-white/5 transition">Explore Services</a>
            <div className="ml-2 inline-flex items-center gap-2 text-xs text-zinc-400">
              <ShieldCheck className="h-4 w-4" /> Mine‑ready • Compliant • Insured
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function TrustStrip(): JSX.Element {
  const items = [
    { icon: Clock, label: "24/7 Field Support" },
    { icon: ShieldCheck, label: "Safety‑first Workmanship" },
    { icon: Settings, label: "OEM‑grade Parts" },
    { icon: Bolt, label: "Fast Turnaround" },
  ];
  return (
    <div className="border-y border-white/10 bg-white/5">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <ul className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 text-sm text-zinc-300">
          {items.map((it, i) => (
            <li key={i} className="flex items-center gap-2">
              <it.icon className="h-5 w-5 text-orange-400" />
              {it.label}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function ServicesSection(): JSX.Element {
  return (
    <section id="services" className="relative py-20">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(1200px_400px_at_50%_-20%,rgba(255,122,0,0.15),transparent)]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <header className="mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold">Core Services</h2>
          <p className="mt-2 text-zinc-400 max-w-2xl">Built for uptime in extreme environments. We engineer reliability into every job.</p>
        </header>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <li key={i} className="group rounded-2xl border border-white/10 bg-white/5 p-6 hover:border-orange-500/30 hover:bg-orange-500/5 transition">
              <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500/10 text-orange-400">
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold">{s.title}</h3>
              <p className="mt-1 text-sm text-zinc-400">{s.blurb}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Industries(): JSX.Element {
  const badges = ["Mining & Yellow Plant", "Earthmoving & Civils", "Logistics Fleets", "Manufacturing Sites"];
  return (
    <section id="industries" className="py-14 border-y border-white/10 bg-white/[0.03]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold">Built for Industry</h2>
            <p className="mt-2 max-w-2xl text-zinc-400">We work on mines—not as miners. Our team specialises in mission‑critical electrical systems on heavy machinery and industrial fleets.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {badges.map((b, i) => (
              <span key={i} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-zinc-300">{b}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function About(): JSX.Element {
  return (
    <section id="about" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold">About Upfront Auto Electrical</h2>
            <p className="mt-4 text-zinc-300">When performance matters, go Upfront. For over 20 years, Upfront Auto Electrical has been the go‑to name in heavy‑duty auto electrical repairs, harness manufacturing, cab refurbishments, and mobile field service across eMalahleni, Witbank, and Mpumalanga.</p>
            <p className="mt-3 text-zinc-300">We specialise in mining vehicle electrical repairs, industrial fleet maintenance, and air‑conditioning services, keeping your machinery running reliably. Our 24/7 call‑out auto electricians are ready to solve electrical faults, rebuild cabs, and keep your fleet operating at peak performance.</p>
            <p className="mt-3 text-zinc-400">Whether you run a single truck or a large mining operation, Upfront Auto Electrical delivers expert solutions you can trust.</p>
            <ul className="mt-4 grid gap-2 text-sm text-zinc-300">
              <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-orange-400" /> Expert workmanship • OEM/aftermarket parts</li>
              <li className="flex items-center gap-2"><Clock className="h-4 w-4 text-orange-400" /> Fast, reliable turnaround</li>
              <li className="flex items-center gap-2"><Bolt className="h-4 w-4 text-orange-400" /> 24/7 call‑out support</li>
            </ul>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <h3 className="text-xl font-bold">Trading Hours</h3>
            <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-2 text-sm text-zinc-300">
              <div>Mon–Thurs</div><div>{CONTACT.hours.monThu}</div>
              <div>Friday</div><div>{CONTACT.hours.fri}</div>
              <div>Call‑outs</div><div>{CONTACT.hours.callouts}</div>
            </div>
            <div className="mt-6 text-sm text-zinc-300">
              <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-orange-400" /> {CONTACT.address}</div>
              <a href={`mailto:${CONTACT.email}`} className="mt-2 inline-flex items-center gap-2 hover:underline"><Mail className="h-4 w-4 text-orange-400" /> {CONTACT.email}</a>
              <a href={CONTACT.whatsappHref} className="mt-2 inline-flex items-center gap-2 hover:underline"><MessageCircle className="h-4 w-4 text-green-400" /> WhatsApp {CONTACT.phoneDisp}</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Gallery(): JSX.Element {
  const items = [
    { src: "/work-1.jpg", caption: "Harness build & test" },
    { src: "/work-2.jpg", caption: "Cab refurbishment" },
    { src: "/work-3.jpg", caption: "On‑site diagnostics" },
    { src: "/work-4.jpg", caption: "Air‑con service" },
    { src: "/work-5.jpg", caption: "OEM‑grade parts" },
    { src: "/work-6.jpg", caption: "Field service bakkie" },
  ];

  return (
    <section id="work" className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <header className="mb-8 flex items=end justify-between">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold">Recent Work</h2>
            <p className="mt-2 text-zinc-400 max-w-2xl">A glimpse into the detail: neat looms, labelled lines, tidy routing, clean cabs.</p>
          </div>
          <a href="#contact" className="hidden sm:inline-flex rounded-xl border border-white/10 px-4 py-2 text-sm text-zinc-300 hover:bg-white/5">Request a site assessment</a>
        </header>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it, i) => (
            <figure key={i} className="group overflow-hidden rounded-2xl border border-white/10 bg-white/5">
              <img src={it.src} alt={it.caption} className="h-56 w-full object-cover object-center group-hover:scale-105 transition" />
              <figcaption className="p-3 text-xs text-zinc-300 border-t border-white/10">{it.caption}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function BrandsStrip(): JSX.Element {
  return (
    <section className="py-14 border-y border-white/10 bg白/[0.03]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h3 className="text-center text-sm uppercase tracking-widest text-zinc-400">Brands we work with</h3>
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6 items-center">
          {BRANDS.map((l, i) => (
            <div key={i} className="flex items-center justify-center py-2 opacity-80 hover:opacity-100 transition">
              <img src={l.src} alt={l.name} className="h-8 w-auto" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA(): JSX.Element {
  return (
    <section id="contact" className="relative isolate py-20">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(800px_300px_at_50%_0%,rgba(255,122,0,0.15),transparent)]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h3 className="text-2xl font-extrabold">Book our mobile team</h3>
            <p className="mt-2 text-zinc-400">Rapid on‑site diagnostics and repairs across Mpumalanga and beyond.</p>
            <div className="mt-6 grid gap-3 text-sm">
              <a href={`tel:${CONTACT.phoneHref}`} className="inline-flex items-center gap-2 rounded-2xl bg-orange-500 px-5 py-3 font-semibold text-black hover:bg-orange-400 w-fit"><Phone className="h-4 w-4" /> {CONTACT.phoneDisp} (Werner)</a>
              <a href={`mailto:${CONTACT.email}`} className="inline-flex items-center gap-2 rounded-2xl border border-white/10 px-5 py-3 hover:bg-white/5 w-fit"><Mail className="h-4 w-4" /> {CONTACT.email}</a>
              <a href={CONTACT.whatsappHref} className="inline-flex items-center gap-2 rounded-2xl border border-white/10 px-5 py-3 hover:bg-white/5 w-fit"><MessageCircle className="h-4 w-4" /> WhatsApp {CONTACT.phoneDisp}</a>
              <div className="inline-flex items-center gap-2 text-zinc-300"><MapPin className="h-4 w-4 text-orange-400" /> {CONTACT.address}</div>
              <div className="inline-flex items-center gap-2 text-zinc-300"><Clock className="h-4 w-4 text-orange-400" /> Mon–Thurs {CONTACT.hours.monThu} • Fri {CONTACT.hours.fri} • Call‑outs {CONTACT.hours.callouts}</div>
            </div>
          </div>
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h3 className="text-2xl font-extrabold">Get a fast quote</h3>
            <form className="mt-6 grid gap-4" onSubmit={(e) => e.preventDefault()}>
              <input className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 outline-none focus:border-orange-500/50" placeholder="Name" />
              <input className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 outline-none focus:border-orange-500/50" placeholder="Phone or Email" />
              <textarea rows={4} className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 outline-none focus:border-orange-500/50" placeholder="How can we help?" />
              <button type="submit" className="rounded-2xl bg-orange-500 px-5 py-3 font-semibold text-black hover:bg-orange-400">Request Quote</button>
              <p className="text-xs text-zinc-500">By submitting you agree to be contacted by Upfront Auto Electrical.</p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function SiteFooter(): JSX.Element {
  return (
    <footer className="border-t border-white/10 bg-black/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src="/upfront-auto-electrical-logo.svg" alt="Upfront Auto Electrical" className="h-7 w-auto" />
            <span className="text-sm text-zinc-400">© {new Date().getFullYear()} Upfront Auto Electrical</span>
          </div>
          <nav className="flex items-center gap-6 text-sm text-zinc-400">
            <a href="#services" className="hover:text-white">Services</a>
            <a href="#industries" className="hover:text-white">Industries</a>
            <a href="#work" className="hover:text-white">Work</a>
            <a href="#about" className="hover:text-white">About</a>
            <a href="#contact" className="hover:text-white">Contact</a>
          </nav>
        </div>
      </div>
    </footer>
  );
}